Linux & macOS : [![Travis Build Status](https://travis-ci.org/Yalir/sfeMovie.svg?branch=master)](https://travis-ci.org/Yalir/sfeMovie)
Windows : [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/xr1rif7b9s8cye63/branch/master?svg=true)](https://ci.appveyor.com/project/Ceylo/sfemovie/branch/master)

See http://sfemovie.yalir.org/ for information on sfeMovie.
