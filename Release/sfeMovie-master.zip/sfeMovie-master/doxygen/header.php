<?php echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" 
   "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
	<head>
		<title>sfeMovie</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" href="$relpath$main.css" />
		<link rel="stylesheet" href="$relpath$footer_helper.css" />
		<link rel="stylesheet" href="$relpath$main_additions.css" />
		<link rel="stylesheet" href="doxygen.css" />
	</head>
	<body>
		<div class="wrapper">
			<?php
			include("../head.php");
			display_head("documentation", "..");
			?>
	       	
			<div id="widescreen_frame"><div class="doxygen"><div>