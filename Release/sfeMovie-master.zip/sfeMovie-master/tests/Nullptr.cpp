#define BOOST_TEST_MAIN
#define BOOST_TEST_MODULE Nullptr
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_CASE(Nullptr)
{
	int* ptr = nullptr;
    BOOST_CHECK(ptr == nullptr);
}

